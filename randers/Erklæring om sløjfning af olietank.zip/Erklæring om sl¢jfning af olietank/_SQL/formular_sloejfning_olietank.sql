﻿-- Table: selvbetjening.formular_sloejfning_olietank

-- DROP TABLE selvbetjening.formular_sloejfning_olietank;

CREATE TABLE selvbetjening.formular_sloejfning_olietank
(
  ogc_fid integer NOT NULL DEFAULT nextval('formular_sloejfning_olietank_ogc_fid_seq'::regclass),
  wkb_geometry geometry,
  address character varying(100),
  placering character varying(50),
  anvendelse character varying(50),
  andenanvendelse character varying(50),
  erklaering character varying(50),
  opvarmning character varying(50),
  andenopvarmning character varying(50),
  tankstoerelse character varying(50),
  fabrikatsaar character varying(50),
  fabrikat character varying(100),
  sloejfningsdato character varying(50),
  navn character varying(50),
  email character varying(50),
  tlf character varying(50),
  id integer,
  formular character varying(100),
  ref character varying(100),
  journalnr character varying(100),
  ts_alteret timestamp without time zone DEFAULT now(),
  CONSTRAINT formular_sloejfning_olietank_pkey PRIMARY KEY (ogc_fid)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE selvbetjening.formular_sloejfning_olietank
  OWNER TO gistestedit;

-- Index: selvbetjening.formular_sloejfning_olietank_geom_idx

-- DROP INDEX selvbetjening.formular_sloejfning_olietank_geom_idx;

CREATE INDEX formular_sloejfning_olietank_geom_idx
  ON selvbetjening.formular_sloejfning_olietank
  USING gist
  (wkb_geometry);

