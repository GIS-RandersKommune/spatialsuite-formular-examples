window.onload = function() 
{
	setTimeout(function() {startUp()},500);
}
function startUp()
{
	//jQuery('#aktivitet').filter('[value="Renovering eller nedrivning af bygninger"]').prop('checked',true);
	checkAktivitet();
	disableFields();	
	setAffaldsType();
	setAffaldsModtager();
	setDagsDato();
	handleDropDowns();
}
function checkAktivitet()
{
	var bygning = jQuery('#aktivitet_bygning').is(':checked');
	var termoruder = jQuery('#aktivitet_termoruder').is(':checked');
	var broer_veje = jQuery('#aktivitet_broer_veje').is(':checked');
	if (bygning || termoruder || broer_veje)
	{
		jQuery('#sendbutton').prop('disabled',false);
		jQuery('#warning').val('false');
	}
	else
	{
		jQuery('#sendbutton').prop('disabled',true);
		jQuery('#warning').val('true');	
	}
}
function setDagsDato()
{
	var d = new Date();
	var strDate = d.getDate() + '-' + (d.getMonth()+1) + "/" + d.getFullYear();
	jQuery('#dags_dato').val(strDate);
}
function disableFields()
{
	jQuery('#ejers_navn').prop('disabled', true);
	jQuery('#ejers_adresse').prop('disabled', true);
	jQuery('#ejendom_matr').prop('disabled', true);
	jQuery('#ejendom_nr').prop('disabled', true);
	jQuery('#plannr').prop('disabled', true);

	jQuery('#byggeaar').prop('disabled', true);
	jQuery('#renoveret').prop('disabled', true);
	jQuery('#renovationsaar').prop('disabled', true);
	
	jQuery('#bygherre_navn').prop('disabled', true);
	jQuery('#adresse_bygherre').prop('disabled', true);
	jQuery('#bygherre_tlf').prop('disabled', true);
	jQuery('#email1').prop('disabled', true);
	jQuery('#email2').prop('disabled', true);
	
	jQuery('#anmelder').prop('disabled', true);
	
	jQuery('#anmelder_navn').prop('disabled', true);
	jQuery('#adresse_anmelder').prop('disabled', true);
	jQuery('#anmelder_tlf').prop('disabled', true);
	jQuery('#email3').prop('disabled', true);
	jQuery('#email4').prop('disabled', true);
}
function setAffaldsType()
{
	jQuery('#affaldstype').val('false');
	var uglaseret_tegl 				= jQuery('#uglaseret_tegl').is(':checked');
	var beton 						= jQuery('#beton').is(':checked');
	var uglaseret_tegl_og_beton 	= jQuery('#uglaseret_tegl_og_beton').is(':checked');
	var jern_og_metal 				= jQuery('#jern_og_metal').is(':checked');
	var glasuld 					= jQuery('#glasuld').is(':checked');
	var asbestholdig_affald 		= jQuery('#asbestholdig_affald').is(':checked');
	var gips						= jQuery('#gips').is(':checked');
	var termoruder					= jQuery('#termoruder').is(':checked');
	var forurenet_byggeaffald		= jQuery('#forurenet_byggeaffald').is(':checked');
 	var farligt_affald				= jQuery('#farligt_affald').is(':checked');
	var andet						= jQuery('#andet').is(':checked');
	if (uglaseret_tegl || beton || uglaseret_tegl_og_beton ||
		jern_og_metal || glasuld || asbestholdig_affald || gips || termoruder ||
		forurenet_byggeaffald || farligt_affald || andet)
		{
			jQuery('#affaldstype').val('true');
		}
	
	
	formular.checkConditions();
}
function setAffaldsModtager()
{
	jQuery('#affaldsmodtager').val('false');
	var forbraending 				= jQuery('#forbraending').is(':checked');
	var deponi 						= jQuery('#deponi').is(':checked');
	var genanvendelse 				= jQuery('#genanvendelse').is(':checked');
	var farligt_affald_modtager 	= jQuery('#farligt_affald_modtager').is(':checked');
	if (forbraending || deponi || genanvendelse || farligt_affald_modtager)
		{
			jQuery('#affaldsmodtager').val('true');
		}
	
	
	formular.checkConditions();
}
function handleDropDowns()
{
	jQuery('#addFile').val('false')
	var facadefuge 			= jQuery('#facadefuge').val();
	var dilationsfuge 		= jQuery('#dilationsfuge').val();
	var termorude 			= jQuery('#termorude').val();
	var maling 				= jQuery('#maling').val();
	var gulv 				= jQuery('#gulv').val();
	var andet_materiale 	= jQuery('#andet_materiale').val();
	if (facadefuge == 'ja' ||
		dilationsfuge == 'ja' ||
		termorude == 'ja' ||
		maling == 'ja' ||
		gulv == 'ja' ||
		andet_materiale == 'ja')
		{
			jQuery('#addFile').val('true')
		}
	formular.checkConditions();
	
}