window.onload = function() 
{
	setTimeout(function() {startUp()},500);
	//jQuery('#sendbutton').on("click",this,myOnTest);
}
function startUp()
{
	checkAktivitet();
	/* jQuery('#rdBtnAkt4').prop('checked', 'checked'); */
	setDagsDato();
	//jQuery('#aktivitet').filter('[value="Bygge-anlægsarbejder"]').prop('checked',true);
	//jQuery('#potentiel_farlig_affald').prop('disabled', true);
	jQuery('#byggeaar').val('');
	jQuery('#renovationsaar').val('');
	handleByggeOrRenovering();
	
	
}
function checkAktivitet()
{
	var bygge = jQuery('#aktivitet_bygge').is(':checked');
	var nedrivning = jQuery('#aktivitet_nedrivning').is(':checked');
	var facade = jQuery('#aktivitet_facadebehandling').is(':checked');
	var overflade = jQuery('#aktivitet_overfladebehandling').is(':checked');
	if (bygge || nedrivning || facade || overflade)
	{
		jQuery('#sendbutton').prop('disabled',false);
		jQuery('#warning').val('false');
	}
	else
	{
		jQuery('#sendbutton').prop('disabled',true);
		jQuery('#warning').val('true');	
	}
}
function setDagsDato()
{
	var d = new Date();
	var strDate = d.getDate() + '-' + (d.getMonth()+1) + "/" + d.getFullYear();
	jQuery('#dags_dato').val(strDate);
}
function handleByggeOrRenovering()
{
	var renoveret = jQuery('#renoveret').val();
	if (!renoveret)
	{
		renoveret = 'Nej'
	}
	var byggeAar = jQuery('#byggeaar').val();
	var renoAar = jQuery('#renovationsaar').val();
	
	
	var potFarligAffald = 'Nej'
	if (renoveret == 'Ja')
	{
		if (byggeAar == '1950-1977')
		{
			potFarligAffald = 'Ja'
		}
		else if (renoAar == '1950-1977')
		{
			potFarligAffald = 'Ja'
		}
	}
	else
	{
		if (byggeAar == '1950-1977')
		{
			potFarligAffald = 'Ja'
		}		
	}
	if (potFarligAffald == 'Ja')
	{
		//formular.messages.done = "Denne fase er afsluttet. Kvittering kan hentes &lt;a href=&quot;{{pdf}}&quot; target=&quot;_blank&quot;&gt;her&lt;/a&gt; - vælg venligst næste fase via knappen herunder.";
	}
	else
	{
		//formular.messages.done = "Tak for din henvendelse. Kvittering kan hentes &lt;a href=&quot;{{pdf}}&quot; target=&quot;_blank&quot;&gt;her&lt;/a&gt;";
	}
	jQuery('#potentiel_farlig_affald').val(potFarligAffald);
	
}
function nextPhase()
{
	if (!window.location.origin) {
		window.location.origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port: '');
	}
	var byggeAar 			= jQuery('#byggeaar').val();
	var renoAar 			= jQuery('#renovationsaar').val();
	var renoveret 			= jQuery('#renoveret').val();
	var potentiel_farlig_affald 	= jQuery('#potentiel_farlig_affald').val();
	var bygherre_navn		= jQuery('#bygherre_navn').val();
	var adresse_bygherre	= jQuery('#adresse_bygherre').val();
	var bygherre_tlf		= jQuery('#bygherre_tlf').val();
	var email1				= jQuery('#email1').val();
	var anmelder			= jQuery('#anmelder').val();
	var anmelder_navn		= jQuery('#anmelder_navn').val();
	var adresse_anmelder	= jQuery('#adresse_anmelder').val();
	var anmelder_tlf		= jQuery('#anmelder_tlf').val();
	var email3				= jQuery('#email3').val();
	var ejers_navn 			= jQuery('#ejers_navn').val();
	var ejers_adresse		= jQuery('#ejers_adresse').val();
	var ejendom_matr 		= jQuery('#ejendom_matr').val();
	var ejendom_nr 			= jQuery('#ejendom_nr').val();
	var plannr 				= jQuery('#plannr').val();
	var adresse 			= jQuery('#adresse').val();
	
	var aktivitet_bygge 				= jQuery('#aktivitet_bygge').is(':checked');
	var aktivitet_nedrivning			= jQuery('#aktivitet_nedrivning').is(':checked');
	var aktivitet_facadebehandling 		= jQuery('#aktivitet_facadebehandling').is(':checked');
	var aktivitet_overfladebehandling	= jQuery('#aktivitet_overfladebehandling').is(':checked');
	
	var baseUrl = window.location.origin;
	var link = "";
	var args = "byggeaar=" + byggeAar;
	args = args + "&renoveret=" + renoveret;
	args = args	+ "&renovationsaar=" + renoAar;
	args = args + "&bygherre_navn=" + bygherre_navn;
	args = args + "&adresse_bygherre=" + adresse_bygherre;
	args = args + "&bygherre_tlf=" + bygherre_tlf;
	args = args + "&email=" + email1;
	args = args + "&anmelder=" + anmelder;
	args = args + "&anmelder_navn=" + anmelder_navn;
	args = args + "&adresse_anmelder=" + adresse_anmelder;
	args = args + "&anmelder_tlf=" + anmelder_tlf;
	args = args + "&anmelder_email=" + email3;
	
	args = args + "&ejers_navn=" + ejers_navn;
	args = args + "&ejers_adresse=" + ejers_adresse;
	args = args + "&ejendom_matr=" + ejendom_matr;
	args = args + "&ejendom_nr=" + ejendom_nr;
	args = args + "&plannr=" + plannr;
	args = args + "&potentiel_farlig_affald=" +potentiel_farlig_affald 
	args = args + "&adresse=" +adresse
	args = args + "&aktivitet_bygge=" +aktivitet_bygge
	args = args + "&aktivitet_nedrivning=" +aktivitet_nedrivning
	args = args + "&aktivitet_facadebehandling=" +aktivitet_facadebehandling
	args = args + "&aktivitet_overfladebehandling=" +aktivitet_overfladebehandling
	
	
	
	link = baseUrl + "/cbkort?page=formular&formular=renoveringsaffald&" + args 
	window.location.assign(link);
}
function handlePlanNr(konfliktObj)
{
	var myData = konfliktObj[0].attributes.value.value;

	var singleDatas = null;
	if (myData.indexOf("\r") > 0)
	{
		//IE Hack
		singleDatas = myData.split("\r");
	}
	else
	{
		singleDatas = myData.split("\n");
	}

	var ejdAdreOpl = '';
	var counter = 0;
	for (var x = 0; x < singleDatas.length; x++)
	{
		var curData = singleDatas[x];
		var singleArr = curData.split(':');
		var curType = singleArr[0];
		var curVaerdi = singleArr[1];
		if (curVaerdi != null)
		{
			curVaerdi = curVaerdi.replace(/^\s+|\s+$/g, '');
			if (curType == 'Plannr')
			{
				jQuery('#plannr').val(curVaerdi);
			}
		}
	}
}
function handleEjer(konfliktObj)
{
	var myData = konfliktObj[0].attributes.value.value;
	var singleDatas = null;
	if (myData.indexOf("\r") > 0)
	{
		//IE Hack
		singleDatas = myData.split("\r");
	}
	else
	{
		singleDatas = myData.split("\n");
	}

	var ejdAdreOpl = '';
	var counter = 0;
	for (var x = 0; x < singleDatas.length; x++)
	{
		var curData = singleDatas[x];
		var singleArr = curData.split(':');
		var curType = singleArr[0];
		var curVaerdi = singleArr[1];
		if (curVaerdi != null)
		{
			curVaerdi = curVaerdi.replace(/^\s+|\s+$/g, '');
			if (curType == 'Ejer')
			{
				jQuery('#ejers_navn').val(curVaerdi);
			}
			if (curType == 'Adresse')
			{
				var adrArray = curVaerdi.split(',');
				if (adrArray.length > 1)
				{
					var vej = adrArray[0].trim();
					var postnr = adrArray[1].trim();
					ejdAdreOpl = vej + ', ' + postnr;
				}

				jQuery('#ejers_adresse').val(ejdAdreOpl);
			}
		}
	}
}
function handleEjendom(konfliktObj)
{
	var myData = konfliktObj[0].attributes.value.value;
	var singleDatas = null;
	if (myData.indexOf("\r") > 0)
	{
		//IE Hack
		singleDatas = myData.split("\r");
	}
	else
	{
		singleDatas = myData.split("\n");
	}

	var ejdAdreOpl = '';
	var counter = 0;
	for (var x = 0; x < singleDatas.length; x++)
	{
		var curData = singleDatas[x];
		var singleArr = curData.split(':');
		var curType = singleArr[0];
		var curVaerdi = singleArr[1];
		if (curVaerdi != null)
		{
			curVaerdi = curVaerdi.replace(/^\s+|\s+$/g, '');
			if (curType == 'Matrikelnummer')
			{
				jQuery('#ejendom_matr').val(curVaerdi);
			}
			if (curType == 'Ejendomsnr')
			{
				jQuery('#ejendom_nr').val(curVaerdi);
			}
		}
	}
}
function setSagsbehandler(sagsbehandlerdata)
{
	jQuery('#conflictdiv_konflikttekst4').hide();
	jQuery('#container_conflictdiv_konflikttekst4').hide();
	var navn = '';
	if (sagsbehandlerdata != null && sagsbehandlerdata.length > 0)
	{
		var sagsbehandler = sagsbehandlerdata[0].value.replace(/[\n\r]/g, ''); 
		var valArray = sagsbehandler.split(':');
		if (valArray != null && valArray.length > 0)
		{
			navn = valArray[1].toLowerCase();
		}
	}
	var sbsysbruger = ''
	var mail = 'kmr@randers.dk'
	switch(navn)
	{
		case 'peter høeg':
			sbsysbruger = 'apkt037';
			break;
		case 'per eriksen':
			sbsysbruger = 'apkt108';
			break;
		case 'jeanette rosager-hansen':
			sbsysbruger = 'apkt039';
			break;
		case 'jonna ploug':
			sbsysbruger = 'apkt048';
			break;
		case 'anja fisker jensen':
			sbsysbruger = 'dq15585';
			break;
		case 'jakob aarup':
			sbsysbruger = 'dq22274';
			mail = 'Jakob.Aarup@randers.dk'
			break;
		case 'christina sass møller':
			sbsysbruger = 'dq15432';
			mail = 'Christina.Sass.Moller@randers.dk'
			break;
    
	}
	jQuery('#sbsys_brugerid').val(sbsysbruger);
	jQuery('#mail_intern').val(mail);
}
function address_change(object){
    if (typeof object.data.type !== "undefined" && object.data.type === "Feature"){
        setAddressFields(object, "adresse");
    }
}
function address_change_bygherre(object){
    if (typeof object.data.type !== "undefined" && object.data.type === "Feature"){
        setAddressFields(object, "adresse_bygherre");
    }
}
function address_change_anmelder(object){
    if (typeof object.data.type !== "undefined" && object.data.type === "Feature"){
        setAddressFields(object, "adresse_anmelder");
    }
}
function setAddressFields(object, id){
    var adr = object.data.properties.adresseringsvejnavn + " " + object.data.properties.husnr + ", " + object.data.properties.postnr + " " + object.data.properties.postnrnavn
	jQuery("#" + id + "_vejhusnr").val(object.data.properties.adresseringsvejnavn + " " + object.data.properties.husnr);
    jQuery("#" + id + "_postdistrikt").val(object.data.properties.postnr + " " + object.data.properties.postnrnavn);
    jQuery("#" + id + "_etageside").val(" ");
	jQuery("#" + id +"").val(adr);
//    jQuery("#address_vejhusnr").val(object.data.properties.adresseringsvejnavn + " " + object.data.properties.husnr);
//    jQuery("#address_postdistrikt").val(object.data.properties.postnr + " " + object.data.properties.postnrnavn);
}

